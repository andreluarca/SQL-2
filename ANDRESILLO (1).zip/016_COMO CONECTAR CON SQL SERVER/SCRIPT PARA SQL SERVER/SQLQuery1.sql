

 create database dbtest

 use dbtest

 create table info(
 identificador int,
 data1 varchar(50),
 data2 varchar(50)
 )

 select * from info

